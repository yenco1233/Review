<?php

namespace App\Modules\Addons\ReviewSystem;

use App\Modules\Addons\AddonModule;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB; // Expliciet de DB-Facade importeren
use Illuminate\Support\Facades\Auth; // Expliciet de Auth-Facade importeren
use Illuminate\Support\Facades\Session; // Expliciet de Session-Facade importeren

class ReviewSystem extends AddonModule
{
    public $name = 'ReviewSystem';

    // --- Installatie en Database ---
    public function install(): bool
    {
        if (!Schema::hasTable('reviews')) {
            Schema::create('reviews', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('client_id');
                $table->unsignedBigInteger('product_id')->nullable();
                $table->integer('rating')->default(5);
                $table->text('comment');
                $table->boolean('approved')->default(false);
                $table->timestamps();
            });
        }
        return true;
    }

    public function uninstall(): bool
    {
        Schema::dropIfExists('reviews');
        return true;
    }

    // --- Klantenzijde Logica ---
    public function clientArea(array $params)
    {
        if (!Auth::guard('client')->check()) {
            return ['redirect' => '/login']; 
        }

        return [
            'pagetitle' => 'Plaats uw Beoordeling',
            'template' => 'review_submit',
            'vars' => [
                'client_id' => Auth::guard('client')->id(),
                'product_id' => request()->input('product_id'),
                'success' => Session::pull('review_success'),
                'error' => Session::pull('review_error')
            ]
        ];
    }

    public function submitReview(Request $request)
    {
        $client = Auth::guard('client')->user();
        if (!$client) {
            return redirect()->back()->with(['review_error' => 'Je moet ingelogd zijn.']);
        }

        $validatedData = $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'required|string|max:5000',
            'product_id' => 'sometimes|integer|nullable',
        ]);

        $needsModeration = $this->getSetting('moderation_enabled', true);

        try {
            DB::table('reviews')->insert([
                'client_id' => $client->id,
                'product_id' => $validatedData['product_id'] ?? null,
                'rating' => $validatedData['rating'],
                'comment' => $validatedData['comment'],
                'approved' => !$needsModeration,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $message = $needsModeration 
                ? 'Bedankt! Uw review is ingediend en zal verschijnen na goedkeuring.' 
                : 'Bedankt! Uw review is succesvol geplaatst.';
            
            return redirect()->back()->with(['review_success' => $message]);

        } catch (\Exception $e) {
            return redirect()->back()->withInput()->with(['review_error' => 'Fout bij indienen.']);
        }
    }

    // --- Beheerders Logica (Moderatie) ---
    public function adminArea(array $params)
    {
        $pendingReviews = DB::table('reviews')
            ->where('approved', false)
            ->join('clients', 'reviews.client_id', '=', 'clients.id')
            ->select('reviews.*', 'clients.first_name', 'clients.last_name')
            ->paginate($this->getSetting('reviews_per_page', 10));

        return [
            'pagetitle' => 'Review Moderatie',
            'template' => 'moderation_list',
            'vars' => [
                'reviews' => $pendingReviews
            ]
        ];
    }
    
    // --- Hook voor Productpagina (Reviews Tonen) ---
    public function hookProductDetails(array $params)
    {
        $productId = $params['product_id'] ?? null;
        
        if (!$productId) {
            return [];
        }

        $approvedReviews = DB::table('reviews')
            ->where('product_id', $productId)
            ->where('approved', true)
            ->orderByDesc('created_at')
            ->get();
        
        $averageRating = $approvedReviews->avg('rating');
        $reviewCount = $approvedReviews->count();

        return [
            'reviews_data' => [
                'approvedReviews' => $approvedReviews,
                'averageRating' => round($averageRating, 1),
                'reviewCount' => $reviewCount,
            ]
        ];
    }
}