@extends('layouts.client')

@section('content')
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Plaats uw Beoordeling</h6>
        </div>
        <div class="card-body">
            @if (isset($success))
                <div class="alert alert-success">{{ $success }}</div>
            @endif
            @if (isset($error))
                <div class="alert alert-danger">{{ $error }}</div>
            @endif

            <form method="POST" action="/client/addon/ReviewSystem/submitReview">
                @csrf 

                @if ($product_id)
                    <input type="hidden" name="product_id" value="{{ $product_id }}">
                    <p class="text-muted">Je bent een review aan het plaatsen voor product #{{ $product_id }}.</p>
                @endif

                <div class="form-group">
                    <label for="rating">Beoordeling (1 tot 5 sterren)</label>
                    <select name="rating" id="rating" class="form-control" required>
                        <option value="5">⭐⭐⭐⭐⭐ Uitstekend</option>
                        <option value="4">⭐⭐⭐⭐ Goed</option>
                        <option value="3">⭐⭐⭐ Gemiddeld</option>
                        <option value="2">⭐⭐ Slecht</option>
                        <option value="1">⭐ Zeer Slecht</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="comment">Uw Commentaar</label>
                    <textarea name="comment" id="comment" rows="5" class="form-control" required>{{ old('comment') }}</textarea>
                </div>

                <button type="submit" class="btn btn-primary">Review Indienen</button>
            </form>
        </div>
    </div>
@endsection
