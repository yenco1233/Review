@extends('layouts.admin')

@section('content')
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Reviews in afwachting van goedkeuring</h6>
        </div>
        <div class="card-body">
            @if ($reviews->isEmpty())
                <p>Er zijn momenteel geen reviews in afwachting van moderatie.</p>
            @else
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Klant</th>
                                <th>Beoordeling</th>
                                <th>Commentaar</th>
                                <th>Actie</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($reviews as $review)
                                <tr>
                                    <td>{{ $review->first_name }} {{ $review->last_name }}</td>
                                    <td>{{ $review->rating }} / 5</td>
                                    <td>{{ Str::limit($review->comment, 100) }}</td>
                                    <td>
                                        <a href="/admin/addon/ReviewSystem/approve/{{ $review->id }}" class="btn btn-sm btn-success">Goedkeuren</a>
                                        <a href="/admin/addon/ReviewSystem/delete/{{ $review->id }}" class="btn btn-sm btn-danger">Verwijderen</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                {{ $reviews->links() }}
            @endif
        </div>
    </div>
@endsection
